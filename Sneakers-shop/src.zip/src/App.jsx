import { Routes, Route } from 'react-router'
import './App.css'
import { HomePage } from './pages/HomePage/HomePage'
import { CheckoutPage } from './pages/CheckoutPage/CheckoutPage'
import { FavoritesPage } from './pages/FavoritesPage/FavoritesPage'
import { CatalogPage } from './pages/CatalogPage/CatalogPage'
import { StoresPage } from './pages/StoresPage/StoresPage'

function App() {

  return (
    <Routes>
      <Route path='/' element={<HomePage/>}/>
      <Route path='/checkout' element={<CheckoutPage/>}/>
      <Route path='/favorites' element={<FavoritesPage/>}/>
      <Route path='/catalog' element={<CatalogPage/>}/>
      <Route path='/stores' element={<StoresPage/>}/>
    </Routes>
  )
}

export default App
