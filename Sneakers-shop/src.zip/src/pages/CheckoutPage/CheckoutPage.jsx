import { Footer } from "../../components/Footer";
import { Header } from "../../components/Header";
import './CheckoutPage.css';
import '../../normalize/adaptive.css'

export function CheckoutPage() {
    return (
        <div>
            <Header />
            <main className="page">
                <div className="container">
                    <div className="cart-head">
                        <div>
                            <h1 className="page__title">Your Cart</h1>
                            <p className="page__sub">2 items</p>
                        </div>
                        <a className="btn btn--outline" href="search.html">← Continue shopping</a>
                    </div>

                    <div className="cart-layout">
                        <section className="cart-items">
                            <div className="card cart-panel">
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Items</h2>
                                    <button className="btn btn--ghost" type="button">Clear cart</button>
                                </div>

                                <div className="cart-list">
                                    <article className="cart-item">
                                        <div className="cart-item__img">
                                            <img src="src/public/images/Nike-Air-Max-90-Infrared-2020.jpg" alt="Nike Air Max 90 Infrared" />
                                        </div>

                                        <div className="cart-item__body">
                                            <div className="cart-item__top">
                                                <div style={{ minWidth: 0 }}>
                                                    <div className="kicker">Nike</div>
                                                    <div className="cart-item__name line-clamp-2">Air Max 90 “Infrared”</div>
                                                    <div className="muted" style={{ fontSize: "13px", fontWeight: 700, marginTop: "6px" }}>
                                                        SKU: AM90-IR-2025
                                                    </div>
                                                </div>

                                                <div className="cart-item__price">
                                                    <div className="price price--md price--primary">$149</div>
                                                    <div className="muted" style={{ fontSize: "12px" }}>Best store offer</div>
                                                </div>
                                            </div>

                                            <div className="cart-item__controls">
                                                <div className="cart-meta">
                                                    <label className="cart-meta__field">
                                                        <span className="cart-meta__label">Size (EU)</span>
                                                        <select className="select select--sm">
                                                            <option>41</option>
                                                            <option selected>42</option>
                                                            <option>43</option>
                                                            <option>44</option>
                                                        </select>
                                                    </label>

                                                    <label className="cart-meta__field">
                                                        <span className="cart-meta__label">Quantity</span>
                                                        <div className="qty">
                                                            <button className="qty__btn" type="button"
                                                                aria-label="Decrease">−</button>
                                                            <input className="qty__input" type="text" value="1"
                                                                inputmode="numeric" />
                                                            <button className="qty__btn" type="button"
                                                                aria-label="Increase">+</button>
                                                        </div>
                                                    </label>
                                                </div>

                                                <div className="cart-actions">
                                                    <button className="btn btn--ghost btn--icon" type="button"
                                                        title="Move to favorites">♥</button>
                                                    <button className="btn btn--ghost btn--icon" type="button"
                                                        title="Remove">🗑</button>
                                                </div>
                                            </div>

                                            <div className="cart-item__bottom">
                                                <span className="badge">🚚 Free delivery</span>
                                                <span className="badge">⏱ 2–5 days</span>
                                                <span className="badge">↩ 14-day returns</span>

                                                <div className="cart-item__subtotal">
                                                    <span className="muted" style={{ fontWeight: 800 }}>Item total</span>
                                                    <span className="price price--md">$149</span>
                                                </div>
                                            </div>
                                        </div>
                                    </article>

                                    <hr className="hr" />

                                    <article className="cart-item">
                                        <div className="cart-item__img">
                                            <img src="src/public/images/adidas-UltraBoost-1.0-DNA-White-Black-Grey.jpg" alt="adidas Ultraboost 1.0" />
                                        </div>

                                        <div className="cart-item__body">
                                            <div className="cart-item__top">
                                                <div style={{ minWidth: 0 }}>
                                                    <div className="kicker">Adidas</div>
                                                    <div className="cart-item__name line-clamp-2">Ultraboost 1.0</div>
                                                    <div className="muted" style={{ fontSize: "13px", fontWeight: 700, marginTop: "6px" }}>
                                                        SKU: HQ4203
                                                    </div>
                                                </div>

                                                <div className="cart-item__price">
                                                    <div className="price price--md price--primary">$169</div>
                                                    <div className="muted" style={{ fontSize: "12px" }}>Best store offer</div>
                                                </div>
                                            </div>

                                            <div className="cart-item__controls">
                                                <div className="cart-meta">
                                                    <label className="cart-meta__field">
                                                        <span className="cart-meta__label">Size (EU)</span>
                                                        <select className="select select--sm">
                                                            <option>41</option>
                                                            <option>42</option>
                                                            <option selected>43</option>
                                                            <option>44</option>
                                                        </select>
                                                    </label>

                                                    <label className="cart-meta__field">
                                                        <span className="cart-meta__label">Quantity</span>
                                                        <div className="qty">
                                                            <button className="qty__btn" type="button"
                                                                aria-label="Decrease">−</button>
                                                            <input className="qty__input" type="text" value="1"
                                                                inputmode="numeric" />
                                                            <button className="qty__btn" type="button"
                                                                aria-label="Increase">+</button>
                                                        </div>
                                                    </label>
                                                </div>

                                                <div className="cart-actions">
                                                    <button className="btn btn--ghost btn--icon" type="button"
                                                        title="Move to favorites">♥</button>
                                                    <button className="btn btn--ghost btn--icon" type="button"
                                                        title="Remove">🗑</button>
                                                </div>
                                            </div>

                                            <div className="cart-item__bottom">
                                                <span className="badge">🚚 +$9 shipping</span>
                                                <span className="badge">⏱ 5–7 days</span>

                                                <div className="cart-item__subtotal">
                                                    <span className="muted" style={{ fontWeight: 800 }}>Item total</span>
                                                    <span className="price price--md">$169</span>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </div>

                            <section style={{ marginTop: "18px" }}>
                                <div className="section__head">
                                    <div>
                                        <h2 className="section__title" style={{ fontSize: "22px" }}>You may also like</h2>
                                        <p className="section__desc">Trending sneakers from similar brands</p>
                                    </div>
                                    <a className="btn btn--ghost" href="search.html"
                                        style={{ color: "hsl(var(--primary))", fontWeight: 900 }}>Browse →</a>
                                </div>

                                <div className="products-grid" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
                                    <article className="product-card">
                                        <a href="product.html" className="product-card__media">
                                            <img className="product-card__img" src="src/public/images/New-Balance-990v6-Made-in-USA-Purple.jpg"
                                                alt="New Balance 990v6" />
                                            <div className="product-card__badge badge">🛍 <span>5 offers</span></div>
                                        </a>
                                        <div className="product-card__body">
                                            <div className="kicker">New Balance</div>
                                            <div className="product-card__name line-clamp-2">990v6 </div>
                                            <div className="product-card__footer">
                                                <span className="price price--md price--primary"><span
                                                    className="price__prefix">from</span>$219</span>
                                            </div>
                                        </div>
                                    </article>

                                    <article className="product-card">
                                        <a href="product.html" className="product-card__media">
                                            <img className="product-card__img" src="src/public/images/Air-Jordan-1-Retro-High-OG-Utility-Stash.jpg"
                                                alt="Air Jordan 1" />
                                            <div className="product-card__badge badge">🛍 <span>9 offers</span></div>
                                        </a>
                                        <div className="product-card__body">
                                            <div className="kicker">Jordan</div>
                                            <div className="product-card__name line-clamp-2">Air Jordan 1 Retro High OG</div>
                                            <div className="product-card__footer">
                                                <span className="price price--md price--primary"><span
                                                    className="price__prefix">from</span>$199</span>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </section>
                        </section>

                        <aside className="cart-summary">
                            <div className="card cart-panel">
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Order Summary</h2>
                                </div>

                                <div className="summary">
                                    <div className="summary-row">
                                        <span className="muted">Subtotal </span>
                                        <span style={{ fontWeight: 700 }}>$318</span>
                                    </div>
                                    <div className="summary-row">
                                        <span className="muted">Shipping </span>
                                        <span style={{ fontWeight: 700 }}>$9</span>
                                    </div>
                                    <div className="summary-row">
                                        <span className="muted">Tax </span>
                                        <span style={{ fontWeight: 700 }}>$0</span>
                                    </div>

                                    <hr className="hr" style={{ margin: "12px 0" }} />

                                    <div className="summary-row summary-total">
                                        <span>Total: </span>
                                        <span className="price price--lg price--primary">$327</span>
                                    </div>

                                    <div className="promo">
                                        <label className="promo__label" for="promo">Promo code</label>
                                        <div className="promo__row">
                                            <input id="promo" className="input" type="text" placeholder="Enter code" />
                                            <button className="btn btn--outline" type="button">Apply</button>
                                        </div>
                                    </div>

                                    <div className="shipping">
                                        <div className="shipping__title">Estimated delivery</div>
                                        <p className="muted" style={{ lineHeight: 1.55 }}>
                                            Between <b>2</b> and <b>7</b> days depending on store and shipping option.
                                        </p>
                                    </div>

                                    <button className="btn btn--primary btn--lg" type="button" style={{ width: "100%" }}>Checkout
                                        →</button>
                                    <button className="btn btn--outline btn--lg" type="button" style={{ width: "100%" }}>Savee payment
                                        methods</button>

                                    <div className="secure">
                                        <span className="badge">🔒 Secure checkout</span>
                                        <span className="badge">💳 Cards & wallets</span>
                                        <span className="badge">↩ Easy returns</span>
                                    </div>
                                </div>
                            </div>

                            <div className="card cart-panel" style={{ marginTop: "14px" }}>
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Need help?</h2>
                                </div>
                                <div style={{ padding: "0 16px 16px" }}>
                                    <p className="muted" style={{ lineHeight: 1.6 }}>
                                        Questions about delivery, returns, or store ratings? We’ll help you compare offers and
                                        choose the best store.
                                    </p>
                                    <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                                        <button className="btn btn--outline" type="button">Support</button>
                                        <button className="btn btn--ghost" type="button"
                                            style={{ color: "hsl(var(--primary))", fontWeight: 900 }}>FAQ →</button>
                                    </div>
                                </div>
                            </div>
                        </aside>
                    </div>

                    <section className="cart-empty card" style={{ marginTop: "18px" }}>
                        <div style={{ padding: "26px", textAlign: "center" }}>
                            <h2 style={{ fontWeight: 900, marginBottom: "10px" }}>Your cart is empty</h2>
                            <p className="muted" style={{ marginBottom: "16px" }}>Find sneakers and add them to your cart to compare store offers.</p>
                            <a className="btn btn--primary btn--lg" href="search.html">Browse sneakers</a>
                        </div>
                    </section>
                    <div style={{ height: "60px" }}></div>
                </div>
            </main>
            <Footer />
        </div>
    )
}