import { Footer } from "../../components/Footer";
import { Header } from "../../components/Header";
import './CheckoutPage.css';
import '../../normalize/adaptive.css'
import { formatMoney } from "../../utils/money";
import { useEffect, useState } from "react";
import axios from "axios";
import { CartList } from "./CartList";

export function CheckoutPage({ cart }) {

    const [deliveryOptions, setdeliveryOptions] = useState([]);
    const [paymentSummary, setPaymentSummary] = useState(null);

    useEffect(() => {
        axios.get('/api/delivery-options?expand=estimatedDeliveryTime')
            .then((response) => {
                setdeliveryOptions(response.data);
            })
            
        axios.get("/api/payment-summary")
            .then((response) => {
                setPaymentSummary(response.data)
            })
    }, [])

    return (
        <div>
            <Header cart={cart}/>
            <main className="page">
                <div className="container">
                    <div className="cart-head">
                        <div>
                            <h1 className="page__title">Your Cart</h1>
                            <p className="page__sub">2 items</p>
                        </div>
                        <a className="btn btn--outline" href="search.html">← Continue shopping</a>
                    </div>

                    <div className="cart-layout">
                        <section className="cart-items">
                            <div className="card cart-panel">
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Items</h2>
                                    <button className="btn btn--ghost" type="button">Clear cart</button>
                                </div>

                                <CartList cart={cart} deliveryOptions={deliveryOptions}/>
                            </div>

                        </section>

                        <aside className="cart-summary">
                            <div className="card cart-panel">
                                
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Order Summary</h2>
                                </div>

                                <div className="summary">

                                    {paymentSummary && (
                                        <>
                                            <div className="summary-row">
                                                <span className="muted">Subtotal </span>
                                                <span style={{ fontWeight: 700 }}>{formatMoney(paymentSummary.productCostCents * 10)}</span>
                                            </div>
                                            <div className="summary-row">
                                                <span className="muted">Shipping </span>
                                                <span style={{ fontWeight: 700 }}>{formatMoney(paymentSummary.shippingCostCents * 10)}</span>
                                            </div>
                                            <div className="summary-row">
                                                <span className="muted">Tax </span>
                                                <span style={{ fontWeight: 700 }}>{formatMoney(paymentSummary.taxCents * 10)}</span>
                                            </div>

                                            <hr className="hr" style={{ margin: "12px 0" }} />

                                            <div className="summary-row summary-total">
                                                <span>Total: </span>
                                                <span className="price price--lg price--primary">{formatMoney(paymentSummary.totalCostCents * 10)}</span>
                                            </div>

                                            <div className="promo">
                                                <label className="promo__label" htmlFor="promo">Promo code</label>
                                                <div className="promo__row">
                                                    <input id="promo" className="input" type="text" placeholder="Enter code" />
                                                    <button className="btn btn--outline" type="button">Apply</button>
                                                </div>
                                            </div>

                                            <div className="shipping">
                                                <div className="shipping__title">Estimated delivery</div>
                                                <p className="muted" style={{ lineHeight: 1.55 }}>
                                                    Between <b>2</b> and <b>7</b> days depending on store and shipping option.
                                                </p>
                                            </div>

                                            <button className="btn btn--primary btn--lg" type="button" style={{ width: "100%" }}>Checkout
                                                →</button>
                                            <button className="btn btn--outline btn--lg" type="button" style={{ width: "100%" }}>Save payment
                                                methods</button>

                                            <div className="secure">
                                                <span className="badge">🔒 Secure checkout</span>
                                                <span className="badge">💳 Cards & wallets</span>
                                                <span className="badge">↩ Easy returns</span>
                                            </div>
                                        </>
                                    )}

                                    
                                </div>
                            </div>

                            <div className="card cart-panel" style={{ marginTop: "14px" }}>
                                <div className="cart-panel__head">
                                    <h2 className="cart-panel__title">Need help?</h2>
                                </div>
                                <div style={{ padding: "0 16px 16px" }}>
                                    <p className="muted" style={{ lineHeight: 1.6 }}>
                                        Questions about delivery, returns, or store ratings? We’ll help you compare offers and
                                        choose the best store.
                                    </p>
                                    <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                                        <button className="btn btn--outline" type="button">Support</button>
                                        <button className="btn btn--ghost" type="button"
                                            style={{ color: "hsl(var(--primary))", fontWeight: 900 }}>FAQ →</button>
                                    </div>
                                </div>
                            </div>
                        </aside>
                    </div>

                    <section className="cart-empty card" style={{ marginTop: "18px" }}>
                        <div style={{ padding: "26px", textAlign: "center" }}>
                            <h2 style={{ fontWeight: 900, marginBottom: "10px" }}>Your cart is empty</h2>
                            <p className="muted" style={{ marginBottom: "16px" }}>Find sneakers and add them to your cart to compare store offers.</p>
                            <a className="btn btn--primary btn--lg" href="search.html">Browse sneakers</a>
                        </div>
                    </section>
                    <div style={{ height: "60px" }}></div>
                </div>
            </main>
            <Footer />
        </div>
    )
}